# Jogo Dinossauro Google Chrome Com JavaScript

- Famoso jogo do Dinossauro desenvolvido em JavaScript, CSS e HTML
- Objetivo é servir como objeto de estudo e prática
- Criado baseado nos estudos com [Digital Innovation One](https://digitalinnovation.one/sign-up?ref=Z0RHSJKM9G)